module.exports.Account = require('./Account.js');
module.exports.Highscore = require('./Highscore.js');
module.exports.Profile = require('./Profile.js');
