// Acts as a relay. Imports stuff just to immediately export it. -SJH
module.exports.Account = require('./Account.js');
module.exports.Game = require('./Game.js');
module.exports.Highscore = require('./Highscore.js');
