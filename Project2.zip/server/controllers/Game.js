// Renders the game page -SJH
const gamePage = async (req, res) => {
  res.render('game');
};

module.exports = {
  gamePage,
};
